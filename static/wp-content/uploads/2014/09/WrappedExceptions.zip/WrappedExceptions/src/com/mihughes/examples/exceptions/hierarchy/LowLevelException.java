package com.mihughes.examples.exceptions.hierarchy;

public class LowLevelException extends Exception {

	public LowLevelException(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 2669374599079443250L;
	

}
